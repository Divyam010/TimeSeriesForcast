def initialize():
    country_set = set()
    date = "datee"
    value = "valuee"
    return country_set, date, value

country_set,date,value = initialize()
